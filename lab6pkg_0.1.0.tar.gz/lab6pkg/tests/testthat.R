library(testthat)
library(lab6pkg)

test_check("lab6pkg")
